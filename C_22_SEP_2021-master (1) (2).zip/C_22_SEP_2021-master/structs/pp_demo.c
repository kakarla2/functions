
#define SIZE 20
#define iseven(n) n % 2 == 0                                    // Macro
#define isleap(y) y % 4 == 0 && y % 100 != 0 || y % 400 == 0    // Macro


void main()
{
  int a[SIZE], i;

     for(i=0; i < SIZE; i ++)
        ;

     for(i=0; i < SIZE; i ++)
        ;

     if(iseven(i))  //  i % 2 == 0
          ;

     if(isleap(i))  // i % 4 == 0 ....
         ;
}

