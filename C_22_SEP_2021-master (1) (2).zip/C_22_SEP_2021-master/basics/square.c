// Program to display square of the given number
// Date : 25-SEP-2021

#include <stdio.h>

void main()
{
  int num, square; // variables

    printf("Enter a number :");
    scanf("%d",&num);

    square = num * num;
    printf("%d",square);
}

