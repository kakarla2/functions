// Cube

#include <stdio.h>

void main()
{
int num,cube;

  printf("Enter a number:");
  scanf("%d",&num);

  cube = num * num * num;

  printf("Cube of %d is %d",num, cube);
}
