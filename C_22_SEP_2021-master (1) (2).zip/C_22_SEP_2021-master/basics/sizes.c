
void main()
{
   printf("%x\n", 255);

   printf("%d %d %d", sizeof(short), sizeof(int) , sizeof(long));
}
