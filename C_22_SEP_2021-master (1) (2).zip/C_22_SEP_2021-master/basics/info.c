// Programs to print details
#include <stdio.h>

void main()
{
   printf("Srikanth Technologies\n");
   printf("9059057000");
}
