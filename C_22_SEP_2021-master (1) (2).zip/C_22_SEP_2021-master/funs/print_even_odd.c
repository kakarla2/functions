// Print even or odd
#include <stdio.h>


void print_odd_even(int num)
{
   if(num % 2 == 0)
     printf("Even");
   else
     printf("Odd");
}

void main()
{
     print_odd_even(10);

}
