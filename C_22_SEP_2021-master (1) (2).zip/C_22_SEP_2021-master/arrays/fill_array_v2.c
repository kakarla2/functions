// Fill array with random numbers

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void main()
{
  int a[10] = {10,22,33,4,5,6,7,19,20,87}, i;

       for(i=0; i < 10; i ++)
       {
          printf("%d\n", a[i]);
       }
}
