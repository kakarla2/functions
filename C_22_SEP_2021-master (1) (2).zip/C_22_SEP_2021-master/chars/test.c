
void main()
{
  char ch;

    ch = 97;

    printf("%c %d",ch,ch);
}
