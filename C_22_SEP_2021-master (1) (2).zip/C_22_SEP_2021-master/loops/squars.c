// print squares of 1 to 25

#include <stdio.h>

void main()
{
    int n;

      n = 1;
      while (n <= 25)
      {
          printf("%5d %5d\n", n, n * n);
          n ++;
      }

} // main()
