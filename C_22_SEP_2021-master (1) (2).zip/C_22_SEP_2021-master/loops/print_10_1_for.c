// print 1 to 10

#include <stdio.h>

void main()
{
    int n;

      for(n = 10; n > 0;  n--)
      {
          printf("%d ", n);
      }

} // main()
