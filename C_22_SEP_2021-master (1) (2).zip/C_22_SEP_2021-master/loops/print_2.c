// print 1 to 10

#include <stdio.h>

void main()
{
    int n;

      n = 1;
      while (n <= 20)
      {
          printf("%d ", n);
          n += 2;
      }

      printf("\nThe End\n");

} // main()
