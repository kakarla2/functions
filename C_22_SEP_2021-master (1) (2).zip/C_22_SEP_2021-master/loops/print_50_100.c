// print 1 to 10

#include <stdio.h>

void main()
{
    int n = 50;

      while (n <= 100)
      {
          printf("%d ", n);
          n += 2;
      }
} // main()
