// print 1 to 10

#include <stdio.h>

void main()
{
    int n;

      n = 10;
      while (n > 0)
      {
          printf("%d ", n);
          n--;
      }

      printf("\nThe End\n");

} // main()
